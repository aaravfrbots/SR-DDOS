import telebot

TOKEN = '7145763460:AAF6ciLujrjaLUSEnvXGUtQSQy_PLVPXNOI'
bot = telebot.TeleBot(TOKEN)

# Remove any existing webhooks
bot.remove_webhook()

# Define your message handlers and other bot logic here
@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    bot.reply_to(message, "Howdy, how are you doing?")

# Start polling
bot.polling()